# lob_engine — C++20 port

Header-only port of the Python limit order book (`lob.hpp`). Same semantics:
price-time priority, maker's-price fills, GTC/IOC/FOK, post-only, market,
stop-market/stop-limit with cascades, iceberg, self-trade prevention,
tick/lot validation, one event per state change.

What changed vs Python: pooled order storage, intrusive doubly-linked list per
price level (true O(1) cancel instead of lazy flags), `uint64` order ids.
Not ported: the unused `in_auction` flag (the Python repo has no uncross path).

## Verify

    make test    # C++ vs Python, event-for-event
    make asan && make test   # same under ASan/UBSan
    make bench && ./bench 100000

`difftest.py` generates randomised flows (all order types, TIFs, STP policies,
tick/lot rejects, duplicate ids, modifies, stop cascades), runs each through both
engines, and requires the full event stream and book state after every operation
to match.

Result: 300 seeds / 599,768 ops / 3,037,776 output lines identical; clean under
ASan + UBSan (60 seeds).

## Benchmark (same machine, same workload shapes as bench.py, N = 100k)

| workload | Python | C++ | speedup |
|---|---|---|---|
| add    | 290k ops/s | 7.3M ops/s  | ~25x |
| cancel | 369k ops/s | 9.6M ops/s  | ~26x |
| mixed  | 313k ops/s | 17.4M ops/s | ~56x |

At N = 1M (cache-bound): add 8.0M, cancel 3.2M, mixed 7.6M ops/s.
Workloads use the same mix as bench.py but a different RNG, so the streams are
not byte-identical.

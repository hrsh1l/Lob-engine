"""Differential test: C++ engine vs the original Python engine.

Generates randomized op scripts (limit GTC/IOC/FOK, post-only, iceberg, market,
stop-market/stop-limit, cancel, modify, duplicate ids, off-tick / odd-lot
rejects, all three STP policies), runs each through BOTH engines, and requires
the full event stream plus book state after every operation to be identical.

usage: python difftest.py <path-to-Lob-engine-checkout> [seeds] [ops_per_seed]
"""
import random, subprocess, sys

repo = sys.argv[1]
SEEDS = int(sys.argv[2]) if len(sys.argv) > 2 else 200
OPS = int(sys.argv[3]) if len(sys.argv) > 3 else 2000
sys.path.insert(0, repo)
from lob.engine import MatchingEngine
from lob.types import Order, Side, TimeInForce
from lob.events import Ack, Canceled, Modified, Rejected, StopPlaced, Triggered
from lob.types import Fill

STP = ["off", "cancel_resting", "cancel_incoming"]
TIFS = [TimeInForce.GTC, TimeInForce.IOC, TimeInForce.FOK]
sc = lambda s: "B" if s is Side.BUY else "S"
side_of = lambda n: Side.SELL if n else Side.BUY


def gen(seed):
    rng = random.Random(seed)
    tick = rng.choice([1, 1, 1, 5])
    lot = rng.choice([1, 1, 1, 10])
    stp = rng.randrange(3)
    ops = [("CFG", tick, lot, stp)]
    ids, nxt = [], 1

    def px(center=100, spread=8):
        p = max(tick, center + rng.randint(-spread, spread))
        if tick > 1 and rng.random() < 0.85:
            p = max(tick, p - p % tick)
        return p

    def qty():
        q = rng.randint(1, 60)
        if lot > 1 and rng.random() < 0.85:
            q = lot * max(1, q // lot)
        return q

    def fresh():
        nonlocal nxt
        if ids and rng.random() < 0.03:
            return rng.choice(ids)            # duplicate id -> reject path
        i = nxt; nxt += 1; ids.append(i); return i

    for _ in range(OPS):
        r = rng.random()
        owner = rng.choice([0, 0, 1, 2, 3])
        if r < 0.42:
            display = rng.choice([0, 0, 0, 0, 5, 12]) if rng.random() < 0.8 else 0
            ops.append(("L", fresh(), rng.randrange(2), px(), qty(), rng.choices([0, 1, 2], [0.78, 0.11, 0.11])[0],
                        1 if rng.random() < 0.08 else 0, owner, display))
        elif r < 0.49:
            ops.append(("M", fresh(), rng.randrange(2), qty(), owner))
        elif r < 0.56:
            price = 0 if rng.random() < 0.5 else px()
            ops.append(("S", fresh(), rng.randrange(2), price, qty(), px(100, 6), owner))
        elif r < 0.72 and ids:
            ops.append(("C", rng.choice(ids)))
        elif ids:
            np_ = 0 if rng.random() < 0.5 else px()
            nq = 0 if rng.random() < 0.4 else qty()
            ops.append(("X", rng.choice(ids), np_, nq))
    return ops


def to_text(ops):
    return "\n".join(" ".join(str(x) for x in op) for op in ops) + "\n"


def fmt_event(e):
    if isinstance(e, Ack): return f"A {e.order_id} {sc(e.side)} {e.price} {e.remaining}"
    if isinstance(e, Fill): return f"F {e.maker_order_id} {e.taker_order_id} {e.price} {e.quantity} {sc(e.taker_side)} {e.trade_id}"
    if isinstance(e, Canceled): return f"C {e.order_id} {e.quantity} {e.reason}"
    if isinstance(e, Modified): return f"M {e.order_id} {e.price} {e.remaining}"
    if isinstance(e, Rejected): return f"R {e.order_id} {e.reason}"
    if isinstance(e, StopPlaced): return f"SP {e.order_id} {sc(e.side)} {e.stop_price} {e.quantity}"
    if isinstance(e, Triggered): return f"T {e.order_id} {e.stop_price}"
    raise TypeError(e)


def depth_txt(levels):
    return ",".join(f"{p}:{q}" for p, q in levels)


def run_python(ops):
    out, eng = [], None
    mk = lambda i, s, p, q, **kw: Order(str(i), side_of(s), p, q, **kw)
    own = lambda o: None if o == 0 else f"u{o}"
    for op in ops:
        k = op[0]
        if k == "CFG":
            eng = MatchingEngine(tick_size=op[1], lot_size=op[2], stp=STP[op[3]]); continue
        if k == "L":
            _, i, s, p, q, tif, post, o, disp = op
            ret = len(eng.submit_limit(mk(i, s, p, q, post_only=bool(post), owner=own(o),
                                          display=disp or None), TIFS[tif]))
        elif k == "M":
            _, i, s, q, o = op
            ret = len(eng.submit_market(mk(i, s, None, q, owner=own(o))))
        elif k == "S":
            _, i, s, p, q, stop, o = op
            ret = int(eng.submit_stop(mk(i, s, p or None, q, owner=own(o)), stop))
        elif k == "C":
            ret = int(eng.cancel(str(op[1])))
        elif k == "X":
            _, i, np_, nq = op
            ret = int(eng.modify(str(i), new_price=np_ or None, new_qty=nq or None))
        out.append(f"RET {ret}")
        out += [fmt_event(e) for e in eng.drain_events()]
        d = eng.depth(10)
        out.append("ST {} {} {} | {} | {}".format(
            -1 if eng.best_bid() is None else eng.best_bid(),
            -1 if eng.best_ask() is None else eng.best_ask(),
            -1 if eng.last_trade_price is None else eng.last_trade_price,
            depth_txt(d["bids"]), depth_txt(d["asks"])))
        oo = sorted(eng.open_orders(), key=lambda o: int(o.order_id))
        out.append("OO" + "".join(f" {o.order_id}:{o.remaining}:{o.visible}" for o in oo))
        out.append("PS" + "".join(f" {o.order_id}:{sp}" for o, sp in eng.pending_stops()))
    return out


def main():
    total_ops = total_lines = 0
    for seed in range(SEEDS):
        ops = gen(seed)
        cpp = subprocess.run(["./diff_driver"], input=to_text(ops), capture_output=True,
                             text=True, check=True).stdout.split("\n")[:-1]
        py = run_python(ops)
        if cpp != py:
            for n, (a, b) in enumerate(zip(cpp, py)):
                if a != b:
                    print(f"MISMATCH seed={seed} line={n}\n  C++   : {a}\n  Python: {b}")
                    print("  context:", *py[max(0, n - 6):n], sep="\n    ")
                    break
            else:
                print(f"MISMATCH seed={seed}: length cpp={len(cpp)} py={len(py)}")
            sys.exit(1)
        total_ops += len(ops) - 1
        total_lines += len(py)
    print(f"OK: {SEEDS} seeds, {total_ops:,} ops, {total_lines:,} output lines identical (C++ == Python)")

main()

// lob.hpp -- C++20 port of hrsh1l/Lob-engine (the pure-Python limit order book).
//
// Same semantics as the Python engine: price-time priority, maker's-price fills,
// GTC/IOC/FOK, post-only, market, stop-market / stop-limit (with cascades),
// iceberg (reload rejoins the back of the queue), self-trade prevention,
// tick/lot validation, and one event per state change.
//
// What changed for C++ (the "what a production engine does differently" list
// from the Python README):
//   * Orders live in a slab/pool and are linked into per-level intrusive
//     doubly-linked lists, so cancel is a true O(1) unlink (no lazy flags).
//   * Order ids are uint64_t instead of strings (no heap-allocated keys).
//   * Price levels sit in a std::map keyed so the best price is begin().
//
// Not ported: the `in_auction` flag. The Python repo has no uncross path, so
// that code can never run to completion.
#pragma once

#include <algorithm>
#include <cstdint>
#include <iterator>
#include <list>
#include <map>
#include <memory>
#include <optional>
#include <stdexcept>
#include <unordered_map>
#include <utility>
#include <vector>

namespace lob {

using Id    = std::uint64_t;
using Price = std::int64_t;   // integer ticks; 0 means "market" in an OrderSpec
using Qty   = std::int64_t;
inline constexpr Price kMarket = 0;

enum class Side : std::uint8_t { Buy, Sell };
enum class Tif  : std::uint8_t { GTC, IOC, FOK };
enum class Stp  : std::uint8_t { Off, CancelResting, CancelIncoming };
enum class EvKind : std::uint8_t { Ack, Fill, Canceled, Modified, Rejected, StopPlaced, Triggered };
enum class Reason : std::uint8_t {
  None, User, IocExpired, FokKill, MarketUnfilled, Modify, Stp,
  PostOnlyWouldCross, DuplicateOrderId, PriceOffTick, OddLot, StopPriceOffTick
};

inline Side opposite(Side s) { return s == Side::Buy ? Side::Sell : Side::Buy; }

inline const char* reason_str(Reason r) {
  switch (r) {
    case Reason::User: return "user";
    case Reason::IocExpired: return "ioc_expired";
    case Reason::FokKill: return "fok_kill";
    case Reason::MarketUnfilled: return "market_unfilled";
    case Reason::Modify: return "modify";
    case Reason::Stp: return "stp";
    case Reason::PostOnlyWouldCross: return "post_only_would_cross";
    case Reason::DuplicateOrderId: return "duplicate_order_id";
    case Reason::PriceOffTick: return "price_off_tick";
    case Reason::OddLot: return "odd_lot";
    case Reason::StopPriceOffTick: return "stop_price_off_tick";
    default: return "";
  }
}

// What a caller submits. price == kMarket (0) marks a market order.
// owner == 0 means "no owner"; display == 0 means "not an iceberg".
struct OrderSpec {
  Id    id;
  Side  side;
  Price price;
  Qty   quantity;
  bool  post_only = false;
  Id    owner     = 0;
  Qty   display   = 0;
};

struct Level;

struct Order {
  Id    id = 0;
  Side  side = Side::Buy;
  Price price = 0;
  Qty   quantity = 0, remaining = 0, visible = 0, display = 0;
  Id    owner = 0;
  bool  post_only = false;
  bool  active = true;
  Order* prev = nullptr;
  Order* next = nullptr;
  Level* level = nullptr;
  bool is_market() const { return price == kMarket; }
};

// One event per state change, in order. Which fields are meaningful:
//   Ack/Modified : id, side(Ack), price, qty = remaining
//   Fill         : id = maker, taker_id, price (maker's), qty, taker_side, trade_id
//   Canceled     : id, qty, reason
//   Rejected     : id, reason
//   StopPlaced   : id, side, price = stop price, qty
//   Triggered    : id, price = stop price
struct Event {
  EvKind kind;
  Side side = Side::Buy, taker_side = Side::Buy;
  Reason reason = Reason::None;
  Id id = 0, taker_id = 0;
  Price price = 0;
  Qty qty = 0;
  std::uint64_t trade_id = 0;
};

// All resting orders at one price, FIFO. `total` is displayed quantity only
// (an iceberg's hidden reserve is invisible), exactly like the Python PriceLevel.
struct Level {
  Price  price = 0;
  Order* head = nullptr;
  Order* tail = nullptr;
  Qty    total = 0;

  void link_back(Order* o) {
    o->prev = tail; o->next = nullptr;
    if (tail) tail->next = o; else head = o;
    tail = o; o->level = this;
  }
  void unlink(Order* o) {
    if (o->prev) o->prev->next = o->next; else head = o->next;
    if (o->next) o->next->prev = o->prev; else tail = o->prev;
    o->prev = o->next = nullptr;
  }
};

class BookSide {
 public:
  explicit BookSide(Side s) : buy_(s == Side::Buy) {}
  Level& get_or_create(Price p) {
    auto [it, inserted] = levels_.try_emplace(key(p));
    if (inserted) it->second.price = p;
    return it->second;
  }
  Level* best() { return levels_.empty() ? nullptr : &levels_.begin()->second; }
  const Level* best() const { return levels_.empty() ? nullptr : &levels_.begin()->second; }
  void erase(const Level& l) { levels_.erase(key(l.price)); }
  const std::map<Price, Level>& levels() const { return levels_; }  // best first
 private:
  // keyed so the best price is always begin(): bids negated, asks as-is
  Price key(Price p) const { return buy_ ? -p : p; }
  bool buy_;
  std::map<Price, Level> levels_;
};

class OrderPool {
 public:
  Order* alloc() {
    if (free_) { Order* p = free_; free_ = p->next; return p; }
    if (used_ == kChunk) { chunks_.emplace_back(new Order[kChunk]); used_ = 0; }
    return &chunks_.back()[used_++];
  }
  void release(Order* p) { p->next = free_; free_ = p; }
 private:
  static constexpr std::size_t kChunk = 4096;
  std::vector<std::unique_ptr<Order[]>> chunks_;
  std::size_t used_ = kChunk;
  Order* free_ = nullptr;
};

class MatchingEngine {
 public:
  explicit MatchingEngine(Price tick_size = 1, Qty lot_size = 1, Stp stp = Stp::Off)
      : tick_(tick_size), lot_(lot_size), stp_(stp) {
    if (tick_ < 1 || lot_ < 1) throw std::invalid_argument("tick_size and lot_size must be >= 1");
    orders_.reserve(1 << 16);
  }

  std::vector<Event> events;   // append-only; call drain_events() or events.clear()

  // ---- order entry (each returns the number of fills; the fills are Fill events)
  std::size_t submit_limit(const OrderSpec& spec, Tif tif = Tif::GTC) {
    if (spec.price == kMarket) throw std::invalid_argument("market orders go through submit_market()");
    Order o = make_order(spec);
    if (!admit(o)) return 0;
    if (o.post_only && would_cross(o)) { reject(o.id, Reason::PostOnlyWouldCross); return 0; }
    if (tif == Tif::FOK && !fillable(o)) { cancel_event(o.id, o.remaining, Reason::FokKill); return 0; }

    std::size_t nf = match(o, o.price);
    if (o.remaining == 0 || !o.active) {
      // fully done, or STP cancelled the incoming remainder
    } else if (tif == Tif::GTC) {
      rest(o);
    } else {
      cancel_event(o.id, o.remaining, Reason::IocExpired);
    }
    if (nf) check_stops();
    return nf;
  }

  std::size_t submit_market(const OrderSpec& spec) {
    if (spec.price != kMarket) throw std::invalid_argument("submit_market() requires price == kMarket");
    Order o = make_order(spec);
    if (!admit(o)) return 0;
    std::size_t nf = match(o, kMarket);
    if (o.remaining > 0 && o.active) cancel_event(o.id, o.remaining, Reason::MarketUnfilled);
    if (nf) check_stops();
    return nf;
  }

  // BUY stop fires when the last trade prints >= stop; SELL stop when <= stop.
  // spec.price == kMarket gives a stop-market, otherwise a stop-limit.
  bool submit_stop(const OrderSpec& spec, Price stop_price) {
    if (stop_price <= 0) throw std::invalid_argument("stop_price must be positive");
    Order o = make_order(spec);
    if (stop_price % tick_) { reject(o.id, Reason::StopPriceOffTick); return false; }
    if (!admit(o)) return false;
    stops_.push_back(StopEntry{o, stop_price});
    stop_index_[o.id] = std::prev(stops_.end());
    Event e{EvKind::StopPlaced}; e.id = o.id; e.side = o.side; e.price = stop_price; e.qty = o.remaining;
    events.push_back(e);
    check_stops();
    return true;
  }

  // ---- cancel / modify
  bool cancel(Id id, Reason reason = Reason::User) {
    if (auto sit = stop_index_.find(id); sit != stop_index_.end()) {
      Qty rem = sit->second->order.remaining;
      stops_.erase(sit->second);
      stop_index_.erase(sit);
      cancel_event(id, rem, reason);
      return true;
    }
    auto it = orders_.find(id);
    if (it == orders_.end()) return false;
    Order* o = it->second;
    orders_.erase(it);
    Level* L = o->level;
    L->total -= o->visible;
    L->unlink(o);
    if (!L->head) side(o->side).erase(*L);
    Qty rem = o->remaining;
    pool_.release(o);
    cancel_event(id, rem, reason);
    return true;
  }

  // new_price == 0 / new_qty == 0 mean "unchanged". A pure quantity decrease is
  // in place (keeps priority); anything else is cancel + re-enter (may trade).
  bool modify(Id id, Price new_price = 0, Qty new_qty = 0) {
    auto it = orders_.find(id);
    if (it == orders_.end()) return false;
    Order* o = it->second;
    Qty target = new_qty ? new_qty : o->remaining;
    if (target <= 0) throw std::invalid_argument("new_qty must be positive; use cancel() to remove");
    bool price_change = new_price != 0 && new_price != o->price;

    if (!price_change && target < o->remaining) {
      Qty old_visible = o->visible;
      o->remaining = target;
      o->visible = std::min(old_visible, target);
      o->level->total -= old_visible - o->visible;
      Event e{EvKind::Modified}; e.id = id; e.price = o->price; e.qty = target;
      events.push_back(e);
      return true;
    }
    if (!price_change && target == o->remaining) return true;  // no-op

    OrderSpec replacement{id, o->side, new_price ? new_price : o->price, target,
                          false, o->owner, o->display};
    cancel(id, Reason::Modify);
    submit_limit(replacement);
    return true;
  }

  // ---- queries
  std::optional<Price> best_bid() const { return best_of(bids_); }
  std::optional<Price> best_ask() const { return best_of(asks_); }
  std::optional<Price> last_trade_price() const { return last_; }

  std::vector<std::pair<Price, Qty>> depth(Side s, std::size_t n = 5) const {
    std::vector<std::pair<Price, Qty>> out;
    for (const auto& [k, L] : (s == Side::Buy ? bids_ : asks_).levels()) {
      out.emplace_back(L.price, L.total);
      if (out.size() == n) break;
    }
    return out;
  }
  const Order* open_order(Id id) const {
    auto it = orders_.find(id);
    return it == orders_.end() ? nullptr : it->second;
  }
  std::size_t open_order_count() const { return orders_.size(); }
  template <class F> void for_each_open_order(F&& f) const { for (const auto& [id, o] : orders_) f(*o); }
  template <class F> void for_each_pending_stop(F&& f) const { for (const auto& e : stops_) f(e.order, e.stop); }

  std::vector<Event> drain_events() { std::vector<Event> out; out.swap(events); return out; }

 private:
  struct StopEntry { Order order; Price stop; };

  static std::optional<Price> best_of(const BookSide& s) {
    const Level* L = s.best();
    return L ? std::optional<Price>(L->price) : std::nullopt;
  }
  BookSide& side(Side s) { return s == Side::Buy ? bids_ : asks_; }
  static bool crosses(Side taker_side, Price taker_price, Price maker_price) {
    return taker_side == Side::Buy ? maker_price <= taker_price : maker_price >= taker_price;
  }

  static Order make_order(const OrderSpec& s) {
    if (s.price < 0) throw std::invalid_argument("price must be positive");
    if (s.quantity <= 0) throw std::invalid_argument("quantity must be positive");
    if (s.display < 0) throw std::invalid_argument("display must be positive");
    Order o;
    o.id = s.id; o.side = s.side; o.price = s.price;
    o.quantity = o.remaining = s.quantity;
    o.owner = s.owner; o.post_only = s.post_only; o.display = s.display;
    o.visible = s.display ? std::min(s.display, o.remaining) : o.remaining;
    return o;
  }

  void reject(Id id, Reason r) {
    Event e{EvKind::Rejected}; e.id = id; e.reason = r; events.push_back(e);
  }
  void cancel_event(Id id, Qty qty, Reason r) {
    Event e{EvKind::Canceled}; e.id = id; e.qty = qty; e.reason = r; events.push_back(e);
  }

  bool admit(const Order& o) {
    if (orders_.count(o.id) || stop_index_.count(o.id)) { reject(o.id, Reason::DuplicateOrderId); return false; }
    if (o.price != kMarket && o.price % tick_) { reject(o.id, Reason::PriceOffTick); return false; }
    if (o.quantity % lot_) { reject(o.id, Reason::OddLot); return false; }
    return true;
  }

  bool would_cross(const Order& o) {
    const Level* best = side(opposite(o.side)).best();
    return best && crosses(o.side, o.price, best->price);
  }

  // FOK pre-check: can the full size trade now? (Counts displayed qty only,
  // like the Python version.)
  bool fillable(const Order& o) {
    Qty needed = o.remaining;
    for (const auto& [k, L] : side(opposite(o.side)).levels()) {
      if (!crosses(o.side, o.price, L.price)) break;
      needed -= L.total;
      if (needed <= 0) return true;
    }
    return false;
  }

  void rest(Order& o) {
    o.visible = o.display ? std::min(o.display, o.remaining) : o.remaining;
    Order* p = pool_.alloc();
    *p = o;
    p->prev = p->next = nullptr;
    Level& L = side(o.side).get_or_create(o.price);
    L.link_back(p);
    L.total += p->visible;
    orders_[o.id] = p;
    Event e{EvKind::Ack}; e.id = o.id; e.side = o.side; e.price = o.price; e.qty = o.remaining;
    events.push_back(e);
  }

  // Cross `taker` against the opposite side. limit == kMarket matches at any price.
  std::size_t match(Order& taker, Price limit) {
    BookSide& opp = side(opposite(taker.side));
    std::size_t nf = 0;
    while (taker.remaining > 0) {
      Level* level = opp.best();
      if (!level) break;
      if (limit != kMarket && !crosses(taker.side, limit, level->price)) break;

      while (taker.remaining > 0 && level->head) {
        Order* maker = level->head;
        if (stp_ != Stp::Off && taker.owner != 0 && maker->owner == taker.owner) {
          if (stp_ == Stp::CancelResting) {
            maker->active = false;
            level->unlink(maker);
            level->total -= maker->visible;
            orders_.erase(maker->id);
            cancel_event(maker->id, maker->remaining, Reason::Stp);
            pool_.release(maker);
            continue;
          }
          taker.active = false;   // cancel_incoming: kill the taker's remainder
          cancel_event(taker.id, taker.remaining, Reason::Stp);
          break;
        }
        Qty q = std::min(taker.remaining, maker->visible);
        maker->remaining -= q; maker->visible -= q;
        taker.remaining  -= q; level->total  -= q;
        Event e{EvKind::Fill};
        e.id = maker->id; e.taker_id = taker.id; e.price = maker->price; e.qty = q;
        e.taker_side = taker.side; e.trade_id = ++next_trade_id_;
        events.push_back(e);
        last_ = maker->price;
        ++nf;
        if (maker->remaining == 0) {
          level->unlink(maker);
          orders_.erase(maker->id);
          pool_.release(maker);
        } else if (maker->visible == 0) {
          // iceberg tranche exhausted: reload and rejoin the BACK of the queue
          level->unlink(maker);
          maker->visible = std::min(maker->display, maker->remaining);
          level->link_back(maker);
          level->total += maker->visible;
        }
      }
      if (!taker.active) break;
      if (!level->head) opp.erase(*level);
    }
    return nf;
  }

  // Fire stops satisfied by the last trade; triggered orders can trade and fire
  // more stops, so loop until quiescent.
  void check_stops() {
    while (!stops_.empty() && last_) {
      Price last = *last_;
      std::vector<Id> fired;
      for (const auto& e : stops_) {
        if ((e.order.side == Side::Buy && last >= e.stop) ||
            (e.order.side == Side::Sell && last <= e.stop))
          fired.push_back(e.order.id);
      }
      if (fired.empty()) return;
      for (Id id : fired) {
        auto sit = stop_index_.find(id);
        StopEntry entry = *sit->second;
        stops_.erase(sit->second);
        stop_index_.erase(sit);
        Event t{EvKind::Triggered}; t.id = id; t.price = entry.stop;
        events.push_back(t);
        Order o = entry.order;
        if (o.is_market()) {
          match(o, kMarket);
          if (o.remaining > 0 && o.active) cancel_event(id, o.remaining, Reason::MarketUnfilled);
        } else {
          match(o, o.price);
          if (o.remaining > 0 && o.active) rest(o);
        }
      }
    }
  }

  Price tick_;
  Qty   lot_;
  Stp   stp_;
  BookSide bids_{Side::Buy}, asks_{Side::Sell};
  OrderPool pool_;
  std::unordered_map<Id, Order*> orders_;
  std::list<StopEntry> stops_;                                   // insertion order
  std::unordered_map<Id, std::list<StopEntry>::iterator> stop_index_;
  std::optional<Price> last_;
  std::uint64_t next_trade_id_ = 0;
};

}  // namespace lob

// diff_driver: reads an op script on stdin, runs it through the C++ engine and
// prints the event stream + book state in a canonical text format. difftest.py
// feeds the same script to the Python engine and compares the two outputs.
#include <algorithm>
#include <cstdio>
#include <iostream>
#include <sstream>
#include <string>
#include "lob.hpp"
using namespace lob;

static char sc(Side s) { return s == Side::Buy ? 'B' : 'S'; }

static void print_events(std::vector<Event>& evs) {
  for (const Event& e : evs) {
    switch (e.kind) {
      case EvKind::Ack:        std::printf("A %llu %c %lld %lld\n", (unsigned long long)e.id, sc(e.side), (long long)e.price, (long long)e.qty); break;
      case EvKind::Fill:       std::printf("F %llu %llu %lld %lld %c %llu\n", (unsigned long long)e.id, (unsigned long long)e.taker_id, (long long)e.price, (long long)e.qty, sc(e.taker_side), (unsigned long long)e.trade_id); break;
      case EvKind::Canceled:   std::printf("C %llu %lld %s\n", (unsigned long long)e.id, (long long)e.qty, reason_str(e.reason)); break;
      case EvKind::Modified:   std::printf("M %llu %lld %lld\n", (unsigned long long)e.id, (long long)e.price, (long long)e.qty); break;
      case EvKind::Rejected:   std::printf("R %llu %s\n", (unsigned long long)e.id, reason_str(e.reason)); break;
      case EvKind::StopPlaced: std::printf("SP %llu %c %lld %lld\n", (unsigned long long)e.id, sc(e.side), (long long)e.price, (long long)e.qty); break;
      case EvKind::Triggered:  std::printf("T %llu %lld\n", (unsigned long long)e.id, (long long)e.price); break;
    }
  }
  evs.clear();
}

static void print_depth(const std::vector<std::pair<Price, Qty>>& d) {
  bool first = true;
  for (auto& [p, q] : d) { std::printf("%s%lld:%lld", first ? "" : ",", (long long)p, (long long)q); first = false; }
}

static void print_state(const MatchingEngine& eng) {
  std::printf("ST %lld %lld %lld | ",
              (long long)eng.best_bid().value_or(-1), (long long)eng.best_ask().value_or(-1),
              (long long)eng.last_trade_price().value_or(-1));
  print_depth(eng.depth(Side::Buy, 10)); std::printf(" | "); print_depth(eng.depth(Side::Sell, 10));
  std::printf("\n");
  struct OO { Id id; Qty rem, vis; };
  std::vector<OO> oo;
  eng.for_each_open_order([&](const Order& o) { oo.push_back({o.id, o.remaining, o.visible}); });
  std::sort(oo.begin(), oo.end(), [](const OO& a, const OO& b) { return a.id < b.id; });
  std::printf("OO");
  for (auto& o : oo) std::printf(" %llu:%lld:%lld", (unsigned long long)o.id, (long long)o.rem, (long long)o.vis);
  std::printf("\nPS");
  eng.for_each_pending_stop([&](const Order& o, Price stop) {
    std::printf(" %llu:%lld", (unsigned long long)o.id, (long long)stop);
  });
  std::printf("\n");
}

int main() {
  std::ios::sync_with_stdio(false);
  std::string line;
  MatchingEngine* eng = nullptr;
  while (std::getline(std::cin, line)) {
    std::istringstream in(line);
    std::string cmd; in >> cmd;
    if (cmd == "CFG") {
      long long tick, lot; int stp; in >> tick >> lot >> stp;
      delete eng;
      eng = new MatchingEngine(tick, lot, static_cast<Stp>(stp));
      continue;
    }
    size_t ret = 0;
    if (cmd == "L") {
      unsigned long long id, owner; int side, tif, post; long long price, qty, display;
      in >> id >> side >> price >> qty >> tif >> post >> owner >> display;
      OrderSpec s{id, side ? Side::Sell : Side::Buy, price, qty, post != 0, owner, display};
      ret = eng->submit_limit(s, static_cast<Tif>(tif));
    } else if (cmd == "M") {
      unsigned long long id, owner; int side; long long qty;
      in >> id >> side >> qty >> owner;
      ret = eng->submit_market(OrderSpec{id, side ? Side::Sell : Side::Buy, kMarket, qty, false, owner, 0});
    } else if (cmd == "S") {
      unsigned long long id, owner; int side; long long price, qty, stop;
      in >> id >> side >> price >> qty >> stop >> owner;
      ret = eng->submit_stop(OrderSpec{id, side ? Side::Sell : Side::Buy, price, qty, false, owner, 0}, stop);
    } else if (cmd == "C") {
      unsigned long long id; in >> id;
      ret = eng->cancel(id);
    } else if (cmd == "X") {
      unsigned long long id; long long np, nq; in >> id >> np >> nq;
      ret = eng->modify(id, np, nq);
    } else continue;
    std::printf("RET %zu\n", ret);
    print_events(eng->events);
    print_state(*eng);
  }
  delete eng;
}

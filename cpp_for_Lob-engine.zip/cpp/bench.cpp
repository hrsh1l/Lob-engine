// Same three workloads as the Python bench.py: add / cancel / mixed (N ops each).
// Scripts are pre-generated so only engine work is timed. Best of 7 runs.
#include <chrono>
#include <cstdio>
#include <random>
#include <string>
#include <variant>
#include "lob.hpp"
using namespace lob;
using Clock = std::chrono::steady_clock;

static size_t N = 100000;

struct Op { bool is_add; Id id; Side side; Price px; Qty qty; };

template <class Setup, class Run>
static void bench(const char* name, size_t n, Setup setup, Run run) {
  double best = 1e30;
  for (int rep = 0; rep < 7; ++rep) {
    auto state = setup();
    auto t0 = Clock::now();
    run(state);
    double dt = std::chrono::duration<double>(Clock::now() - t0).count();
    best = std::min(best, dt);
  }
  std::printf("%-8s %10zu ops in %7.4fs  -> %12.0f ops/s  (%.3f us/op)\n",
              name, n, best, n / best, best / n * 1e6);
}

int main(int argc, char** argv) {
  if (argc > 1) N = std::stoull(argv[1]);
  std::printf("lob_engine C++ benchmark, N=%zu per workload\n\n", N);

  // 1. add: non-crossing GTC limits. bids 50-99, asks 101-150
  struct AddState { MatchingEngine eng; std::vector<OrderSpec> orders; };
  bench("add", N, [] {
    AddState s; std::mt19937_64 rng(7);
    for (size_t i = 0; i < N; ++i) {
      bool buy = rng() & 1;
      Price px = buy ? 50 + rng() % 50 : 101 + rng() % 50;
      s.orders.push_back({i + 1, buy ? Side::Buy : Side::Sell, px, Qty(1 + rng() % 100)});
    }
    return s;
  }, [](AddState& s) { for (auto& o : s.orders) s.eng.submit_limit(o); });

  // 2. cancel: add N resting orders, then cancel all N in shuffled order
  struct CancelState { MatchingEngine eng; std::vector<Id> ids; };
  bench("cancel", N, [] {
    CancelState s; std::mt19937_64 rng(8);
    for (size_t i = 0; i < N; ++i) {
      s.eng.submit_limit({i + 1, Side::Buy, Price(50 + rng() % 50), Qty(1 + rng() % 100)});
      s.ids.push_back(i + 1);
    }
    s.eng.events.clear();
    std::shuffle(s.ids.begin(), s.ids.end(), rng);
    return s;
  }, [](CancelState& s) { for (Id id : s.ids) s.eng.cancel(id); });

  // 3. mixed: 50% add, 30% cancel, 20% aggressive limits crossing several levels
  struct MixState { MatchingEngine eng; std::vector<Op> script; };
  bench("mixed", N, [] {
    MixState s; std::mt19937_64 rng(9);
    std::vector<Id> live;
    auto u = [&] { return std::uniform_real_distribution<>(0, 1)(rng); };
    for (size_t i = 0; i < N; ++i) {
      double r = u();
      if (r < 0.5 || live.empty()) {
        bool buy = rng() & 1;
        Price px = buy ? 95 + rng() % 5 : 101 + rng() % 5;
        s.script.push_back({true, i + 1, buy ? Side::Buy : Side::Sell, px, Qty(1 + rng() % 50)});
        live.push_back(i + 1);
      } else if (r < 0.8) {
        size_t k = rng() % live.size();
        s.script.push_back({false, live[k], Side::Buy, 0, 0});
        live[k] = live.back(); live.pop_back();
      } else {
        bool buy = rng() & 1;
        s.script.push_back({true, i + 1, buy ? Side::Buy : Side::Sell, buy ? 105 : 95, Qty(1 + rng() % 50)});
      }
    }
    return s;
  }, [](MixState& s) {
    for (auto& op : s.script) {
      if (op.is_add) s.eng.submit_limit({op.id, op.side, op.px, op.qty});
      else s.eng.cancel(op.id);
      s.eng.events.clear();
    }
  });
}
